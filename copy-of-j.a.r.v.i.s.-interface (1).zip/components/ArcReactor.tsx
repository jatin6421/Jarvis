import React from 'react';

interface ArcReactorProps {
  active: boolean;
  volume: number; // 0 to 1 (can spike higher)
}

const ArcReactor: React.FC<ArcReactorProps> = ({ active, volume }) => {
  // Map volume to scale and glow intensity
  const scale = 1 + Math.min(volume, 0.4); 
  const glow = active ? `0 0 ${20 + volume * 40}px #06b6d4` : '0 0 15px #0f172a';
  const innerColor = active ? '#06b6d4' : '#1e293b';
  const ringColor = active ? 'border-cyan-400' : 'border-slate-800';

  return (
    <div className="relative flex items-center justify-center w-full aspect-square max-w-[280px] lg:max-w-[320px]">
      {/* Outer Ring with Rotation */}
      <div 
        className={`absolute w-full h-full rounded-full border-4 ${ringColor} border-dashed opacity-50 ${active ? 'animate-[spin_10s_linear_infinite]' : ''}`}
      />
      
      {/* Middle Ring with Counter Rotation */}
      <div 
        className={`absolute w-[85%] h-[85%] rounded-full border-2 ${ringColor} opacity-70 ${active ? 'animate-[spin_8s_linear_infinite_reverse]' : ''}`}
      />

      {/* Core Container - Pulsing */}
      <div 
        className="relative flex items-center justify-center w-[60%] h-[60%] rounded-full transition-all duration-100 ease-out z-10"
        style={{ 
            transform: `scale(${scale})`,
            boxShadow: glow,
            backgroundColor: 'rgba(0,0,0,0.6)',
            border: `2px solid ${innerColor}`
        }}
      >
        {/* The Triangle/Heart Shape approximation */}
        <div className={`w-0 h-0 border-l-[25px] border-l-transparent border-r-[25px] border-r-transparent border-b-[40px] md:border-l-[30px] md:border-r-[30px] md:border-b-[50px] ${active ? 'border-b-cyan-200' : 'border-b-slate-700'} opacity-90 drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]`} />
        
        {/* Inner glow circle */}
        <div className={`absolute w-[70%] h-[70%] rounded-full border border-white opacity-30`} />
      </div>

      {/* Decorative Text Rings */}
      <div className="absolute w-[110%] h-[110%] rounded-full flex items-center justify-center pointer-events-none opacity-60">
         <div className="absolute top-0 text-[8px] md:text-[10px] text-cyan-800 font-mono tracking-widest animate-[pulse_4s_infinite]">SYSTEM ACTIVE // MK.VII</div>
         <div className="absolute bottom-0 text-[8px] md:text-[10px] text-cyan-800 font-mono tracking-widest animate-[pulse_4s_infinite]">PALLADIUM CORE</div>
         <div className="absolute left-0 -rotate-90 text-[8px] md:text-[10px] text-cyan-900 font-mono tracking-widest">SYS.NOMINAL</div>
         <div className="absolute right-0 rotate-90 text-[8px] md:text-[10px] text-cyan-900 font-mono tracking-widest">PWR.OUTPUT</div>
      </div>
    </div>
  );
};

export default ArcReactor;