import React, { useEffect, useState, useRef } from 'react';
import { Message } from '../types';

interface StatusPanelProps {
  messages: Message[];
  isVisionEnabled: boolean;
  mobileStatus: string;
}

const StatusPanel: React.FC<StatusPanelProps> = ({ messages, isVisionEnabled, mobileStatus }) => {
  const [time, setTime] = useState(new Date());
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [batteryLevel, setBatteryLevel] = useState<number>(100);
  const [isCharging, setIsCharging] = useState(false);
  const [connectionType, setConnectionType] = useState<string>('SECURE');
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    
    // Geolocation
    navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => console.log('Location denied')
    );

    // Battery API
    if ('getBattery' in navigator) {
        (navigator as any).getBattery().then((battery: any) => {
            const updateBattery = () => {
                setBatteryLevel(Math.floor(battery.level * 100));
                setIsCharging(battery.charging);
            };
            updateBattery();
            battery.addEventListener('levelchange', updateBattery);
            battery.addEventListener('chargingchange', updateBattery);
        });
    }

    // Network API
    if ('connection' in navigator) {
        const conn = (navigator as any).connection;
        const updateConnection = () => {
            setConnectionType(conn.effectiveType ? conn.effectiveType.toUpperCase() : 'WIFI');
        };
        updateConnection();
        conn.addEventListener('change', updateConnection);
    }

    return () => clearInterval(timer);
  }, []);

  // Auto-scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
        logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Check if translation is active based on last log
  const isTranslating = messages.length > 0 && messages[messages.length - 1].text.includes("TRANSLATION MATRIX");

  return (
    <div className="flex flex-col h-full w-full gap-3 font-mono text-xs uppercase tracking-widest text-cyan-600">
      
      {/* Header Block */}
      <div className="border border-cyan-800/50 bg-cyan-950/10 p-3 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-1">
            <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isCharging ? 'bg-green-500' : 'bg-cyan-500'}`}></div>
        </div>
        <div className="absolute left-0 top-0 w-0.5 h-full bg-cyan-800"></div>
        <h2 className="text-cyan-400 font-bold text-sm mb-2 tracking-[0.2em]">DIAGNOSTICS</h2>
        <div className="flex justify-between text-[10px] text-cyan-700">
            <span>T: {time.toLocaleTimeString()}</span>
            <span>NET: {connectionType}</span>
        </div>
        <div className="flex justify-between text-[10px] text-cyan-700 mt-1">
             <span>LOC: {location?.lat.toFixed(2) || '--'} / {location?.lng.toFixed(2) || '--'}</span>
             <span>PWR: {batteryLevel}%</span>
        </div>
      </div>

      {/* Modules Grid */}
      <div className="grid grid-cols-2 gap-2 shrink-0">
        <div className="border border-cyan-900/50 p-2 flex flex-col justify-between h-16 bg-black/40">
            <span className="text-cyan-800 text-[9px]">REACTOR</span>
            <div className="flex items-center justify-between">
                <span className={`text-lg leading-none ${batteryLevel < 20 ? 'text-red-500' : 'text-cyan-300'}`}>{batteryLevel}%</span>
                <div className={`h-4 w-4 rounded-full border ${batteryLevel < 20 ? 'border-red-500' : 'border-cyan-500'} animate-spin`}></div>
            </div>
        </div>
        
        <div className="border border-cyan-900/50 p-2 flex flex-col justify-between h-16 bg-black/40 overflow-hidden">
            <span className="text-cyan-800 text-[9px]">UPLINK</span>
            <div className="flex flex-col justify-end">
                <span className="text-cyan-300 text-[10px] truncate">{mobileStatus}</span>
                <div className="w-full bg-cyan-900/30 h-0.5 mt-1">
                    <div className="bg-cyan-500 h-full animate-pulse" style={{ width: '100%' }}></div>
                </div>
            </div>
        </div>

        <div className="border border-cyan-900/50 p-2 flex flex-col justify-between h-16 bg-black/40">
            <span className="text-cyan-800 text-[9px]">VISION</span>
            <span className={`text-sm ${isVisionEnabled ? 'text-green-400' : 'text-amber-600'}`}>
                {isVisionEnabled ? 'ON' : 'STBY'}
            </span>
        </div>

        <div className="border border-cyan-900/50 p-2 flex flex-col justify-between h-16 bg-black/40">
            <span className="text-cyan-800 text-[9px]">AUDIO</span>
            <span className="text-sm text-green-400">OK</span>
        </div>
      </div>

      <div className="border border-cyan-900/50 p-2 flex items-center justify-between bg-black/40 h-10 shrink-0">
         <span className="text-cyan-800 text-[9px]">TRANSLATOR</span>
         <div className="flex items-center gap-2">
            <span className={`text-[10px] ${isTranslating ? 'text-orange-400 animate-pulse' : 'text-cyan-900'}`}>
                {isTranslating ? 'ACTIVE' : 'IDLE'}
            </span>
            <div className={`w-1.5 h-1.5 rounded-full ${isTranslating ? 'bg-orange-500' : 'bg-cyan-900'}`}></div>
         </div>
      </div>

      {/* Logs Console - Flex Grow to fill remaining space */}
      <div className="flex-1 flex flex-col border border-cyan-900/50 bg-black/60 overflow-hidden relative min-h-[150px] lg:min-h-0">
         <div className="bg-cyan-950/30 px-2 py-1 text-[9px] text-cyan-600 border-b border-cyan-900/30 flex justify-between shrink-0">
            <span>TERMINAL</span>
            <span>SECURE</span>
         </div>
         <div 
            ref={logContainerRef}
            className="flex-1 overflow-y-auto p-2 font-mono space-y-1 scroll-smooth"
         >
            {messages.length === 0 && <span className="text-cyan-900 text-[10px]">Awaiting command...</span>}
            {messages.map((msg) => (
                <div key={msg.id} className="flex gap-2 text-[10px] leading-tight text-cyan-500/80 hover:text-cyan-300">
                    <span className="text-cyan-800 shrink-0">[{msg.timestamp.toLocaleTimeString().split(' ')[0]}]</span>
                    <span className="break-words">{'>'} {msg.text}</span>
                </div>
            ))}
         </div>
         {/* Scan line effect */}
         <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 bg-[length:100%_2px,3px_100%] opacity-20"></div>
      </div>

    </div>
  );
};

export default StatusPanel;