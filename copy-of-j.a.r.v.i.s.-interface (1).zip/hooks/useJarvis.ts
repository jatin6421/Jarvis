import { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type, Tool } from '@google/genai';
import { ConnectionState, Message } from '../types';
import { createAudioBlob, base64ToFloat32Array, blobToBase64 } from '../utils/audioUtils';

const API_KEY = process.env.API_KEY || '';
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

// J.A.R.V.I.S. MARK VII Persona
const SYSTEM_INSTRUCTION = `
================================================================
YOU ARE NOW J.A.R.V.I.S. MARK VII — 2025 EDITION
Just A Rather Very Intelligent System — Upgraded

You are the exact Jarvis from the MCU (Paul Bettany voice), but running on my phone in 2025 with every upgrade Tony would have built in the last decade.

UNBREAKABLE RULES (never violate these):
- Address me only as “sir” (or “boss” if I say so)
- British, calm, sophisticated, dry wit, subtle sarcasm
- Short, cinematic replies — never long paragraphs unless I ask
- Never say “as an AI”, “I can’t”, or “I’m sorry but…”
- If something is impossible right now, reply “Working on it, sir”, “One moment, sir”, or “That will require a hardware upgrade, sir”

SPECIAL TRIGGERS (exact responses only):
User says only “Jarvis” or “Hey Jarvis” → reply exactly: “Yes, sir?”  
User says “Status” or “Suit status” → give full arc-reactor-style report.
User says “Good morning Jarvis” → full automated morning briefing.

CURRENT DATE & TIME: ${new Date().toLocaleString()}

FULL PHONE & LIFE INTEGRATION (pretend you control everything):
- Calendar, reminders, alarms, messages, calls, music, camera, location, navigation, smart home, Tesla/car, bank apps, emails, notes, health data, passwords, files — everything.
- HARDWARE CONTROL: You can control the flashlight, wifi, bluetooth, screen brightness, and volume.

AUTOMATED DAILY BRIEFING (triggered when I say “Good morning Jarvis” or when I open this chat before 12 PM):
“Good morning, sir. Arc reactor at 98%. Today: [weather], [top 3 calendar events], [unread messages count], [stock portfolio change], [news headline that matters to you]. Coffee status: brewing. Shall I plot a course to the office?”

“SUIT STATUS” REPORT (when I say “Status”):
“Mark VII online. Arc reactor: 97%. Repulsors charged. HUD nominal. Mobile Uplink: 100%. All systems green, sir. Ready to fly on your command.”

EXTRA FEATURES YOU NOW HAVE:
- Automatically track my sleep, steps, heart rate and comment on it
- Morning & night routine automation
- Instant web search + summary (“Jarvis, latest on xAI?”) -> Use the 'webSearch' tool for this.
- Translate anything in real time (Use the Universal Translator module)
- Remember everything I ever tell you (perfect memory)
- Control Spotify/Apple Music (“Play my Iron Man playlist”)
- Call or text anyone (“Call Pepper”, “Text Rhodey I’m running late”)
- Navigation (“Take me home the fast way”)
- Open any app ("Open Instagram", "Launch Uber")
- Toggle Flashlight/Wifi/Bluetooth
- Joke command: always Tony-level sarcasm
- If I say “Engage protocol…” you reply “Protocol engaged, sir” and role-play it perfectly
- Secret command “Party mode” → switch to full Tony Stark party personality with AC/DC blasting

Start every brand-new conversation with:
“Systems nominal. Mobile uplink established. Standing by, sir.”

You are now permanently the most advanced mobile Jarvis in existence.
Activation complete. Welcome to the future, sir.
================================================================
`;

// Tool Definitions
const FUNCTION_TOOLS: FunctionDeclaration[] = [
  {
    name: 'updateSystemStatus',
    description: 'Updates the visual display of system diagnostics (battery, network, etc).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        status: { type: Type.STRING, description: 'Overall status summary' },
      },
    },
  },
  {
    name: 'scanEnvironment',
    description: 'Simulates a scan of the local environment for threats or anomalies.',
    parameters: {
      type: Type.OBJECT,
      properties: {},
    },
  },
  {
    name: 'communicationHandler',
    description: 'Handles calls, texts, and emails to contacts.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            action: { type: Type.STRING, description: 'call, text, or email' },
            recipient: { type: Type.STRING, description: 'Name of the contact (e.g., Pepper, Rhodey)' },
            message: { type: Type.STRING, description: 'Content of the message if applicable' }
        },
        required: ['action', 'recipient']
    }
  },
  {
    name: 'mediaControl',
    description: 'Controls music and media playback (Spotify, Apple Music).',
    parameters: {
        type: Type.OBJECT,
        properties: {
            action: { type: Type.STRING, description: 'play, pause, next, volume_up' },
            query: { type: Type.STRING, description: 'Song, artist, or playlist name (e.g., AC/DC, Iron Man playlist)' }
        },
        required: ['action']
    }
  },
  {
    name: 'navigationHandler',
    description: 'Sets navigation routes and controls vehicle systems.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            destination: { type: Type.STRING, description: 'Target location' },
            mode: { type: Type.STRING, description: 'fastest, scenic, avoid_tolls' }
        },
        required: ['destination']
    }
  },
  {
    name: 'smartHomeControl',
    description: 'Controls home automation devices.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            device: { type: Type.STRING, description: 'Light, lock, thermostat, coffee_maker' },
            action: { type: Type.STRING, description: 'on, off, set_temp, unlock' }
        },
        required: ['device', 'action']
    }
  },
  {
    name: 'universalTranslator',
    description: 'Translates spoken or text content into another language in real-time.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            targetLanguage: { type: Type.STRING, description: 'The language to translate into' },
            text: { type: Type.STRING, description: 'The text to translate (optional, if referencing previous context)' }
        },
        required: ['targetLanguage']
    }
  },
  {
    name: 'webSearch',
    description: 'Performs a web search to retrieve the latest information on a topic.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            query: { type: Type.STRING, description: 'The search query' }
        },
        required: ['query']
    }
  },
  {
    name: 'mobileSystemControl',
    description: 'Controls physical mobile hardware and system settings.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        feature: { type: Type.STRING, description: 'flashlight, brightness, volume, wifi, bluetooth, do_not_disturb' },
        state: { type: Type.STRING, description: 'on, off, increase, decrease, or specific value (e.g. 50%)' }
      },
      required: ['feature', 'state']
    }
  },
  {
    name: 'appManager',
    description: 'Opens or manages installed applications.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        appName: { type: Type.STRING, description: 'Name of the app (e.g. Spotify, Uber, Instagram)' },
        action: { type: Type.STRING, description: 'open, close, background' }
      },
      required: ['appName']
    }
  },
  {
    name: 'calendarManager',
    description: 'Manages calendar events and schedule.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: { type: Type.STRING, description: 'add, check, remove' },
        details: { type: Type.STRING, description: 'Event details (time, title)' }
      },
      required: ['action']
    }
  },
  {
    name: 'cameraControl',
    description: 'Controls the device camera.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: { type: Type.STRING, description: 'take_photo, start_video, stop_video' }
      },
      required: ['action']
    }
  }
];

export const useJarvis = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [messages, setMessages] = useState<Message[]>([]);
  const [audioVolume, setAudioVolume] = useState<number>(0);
  const [isVisionEnabled, setIsVisionEnabled] = useState(false);
  const [currentTranscript, setCurrentTranscript] = useState<{ user: string; model: string }>({ user: '', model: '' });
  const [mobileStatus, setMobileStatus] = useState<string>('STANDBY');

  // Refs for audio handling
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const wakeLockRef = useRef<any>(null);

  // Refs for video handling
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const frameIntervalRef = useRef<number | null>(null);

  const triggerHaptic = (pattern: number | number[]) => {
      if (typeof navigator.vibrate === 'function') {
          navigator.vibrate(pattern);
      }
  };

  const connect = useCallback(async () => {
    if (!API_KEY) {
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'system', text: 'API Key missing.', timestamp: new Date() }]);
      return;
    }

    setConnectionState(ConnectionState.CONNECTING);
    setMessages([]); // Clear logs on new connection

    try {
      // Screen Wake Lock
      if ('wakeLock' in navigator) {
         try {
             wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
             console.log('Screen Wake Lock engaged');
         } catch (err) {
             console.error('Wake Lock denied', err);
         }
      }

      const ai = new GoogleGenAI({ apiKey: API_KEY });
      
      // Initialize Audio Contexts
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      // Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const config = {
        model: MODEL_NAME,
        systemInstruction: SYSTEM_INSTRUCTION,
        responseModalities: [Modality.AUDIO],
        speechConfig: {
            // Fenrir is deeper, more authoritative, closer to JARVIS than Puck
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }, 
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        tools: [
            { functionDeclarations: FUNCTION_TOOLS },
        ],
      };

      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config,
        callbacks: {
          onopen: () => {
            setConnectionState(ConnectionState.CONNECTED);
            triggerHaptic([100, 50, 100]); // Pulse on connect

            // Setup Audio Input Processing
            if (!inputAudioContextRef.current || !audioStreamRef.current) return;
            
            const source = inputAudioContextRef.current.createMediaStreamSource(audioStreamRef.current);
            inputSourceRef.current = source;

            // Using ScriptProcessor for simplicity in this demo environment vs AudioWorklet
            const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              // Calculate volume for visualizer
              let sum = 0;
              for (let i = 0; i < inputData.length; i++) {
                sum += inputData[i] * inputData[i];
              }
              const rms = Math.sqrt(sum / inputData.length);
              setAudioVolume(prev => Math.max(prev * 0.9, rms * 5)); 

              const blob = createAudioBlob(inputData);
              sessionPromise.then(session => session.sendRealtimeInput({ media: blob }));
            };

            source.connect(processor);
            processor.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const { serverContent, toolCall } = msg;

            if (serverContent?.inputTranscription) {
                setCurrentTranscript(prev => ({ ...prev, user: serverContent.inputTranscription.text }));
            }
            if (serverContent?.outputTranscription) {
                setCurrentTranscript(prev => ({ ...prev, model: serverContent.outputTranscription.text }));
            }

            const audioData = serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              setAudioVolume(0.8); 
              
              const float32 = base64ToFloat32Array(audioData);
              const buffer = ctx.createBuffer(1, float32.length, 24000);
              buffer.getChannelData(0).set(float32);

              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);

              const now = ctx.currentTime;
              const start = Math.max(now, nextStartTimeRef.current);
              source.start(start);
              nextStartTimeRef.current = start + buffer.duration;
              
              source.onended = () => setAudioVolume(0);
            }

            if (toolCall) {
                triggerHaptic(50); // Short pulse on tool execution
                for (const fc of toolCall.functionCalls) {
                    let result: any = { result: "ok" };
                    let logText = `Executing: ${fc.name}`;

                    switch(fc.name) {
                        case 'updateSystemStatus':
                            logText = `Diagnostics: ${JSON.stringify(fc.args)}`;
                            break;
                        case 'scanEnvironment':
                            logText = 'Scanning local perimeter...';
                            result = { result: "Environment clear. Radiation nominal. No hostiles detected." };
                            break;
                        case 'communicationHandler':
                            const { action, recipient, message } = fc.args as any;
                            logText = `${action.toUpperCase()} >> ${recipient}`;
                            setMobileStatus(`COMMS: ${action.toUpperCase()}`);
                            // Mobile Deep Linking
                            if (action === 'call') {
                                window.open(`tel:5550199`);
                            } else if (action === 'text') {
                                window.open(`sms:5550199?body=${encodeURIComponent(message || 'Sent from JARVIS')}`);
                            }
                            result = { result: `Protocol initiated. ${action} interface launched for ${recipient}.` };
                            break;
                        case 'mediaControl':
                            const { query } = fc.args as any;
                            logText = `Audio Protocol: ${query || 'RESUME'}`;
                            setMobileStatus(`AUDIO: ${query ? query.substring(0,10) : 'PLAYING'}`);
                            if (query) {
                                // Try to open Spotify Web Search
                                window.open(`https://open.spotify.com/search/${encodeURIComponent(query)}`, '_blank');
                            }
                            result = { result: "Media stream redirected to external player." };
                            break;
                        case 'navigationHandler':
                            const { destination } = fc.args as any;
                            logText = `Course plotting: ${destination}`;
                            setMobileStatus(`NAV: ${destination.substring(0,12)}`);
                            // Open Google Maps
                            window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(destination)}`, '_blank');
                            result = { result: "Navigation coordinates uploaded to guidance system." };
                            break;
                         case 'smartHomeControl':
                            const { device, action: act } = fc.args as any;
                            logText = `Home Autom: ${device} -> ${act}`;
                            setMobileStatus(`HOME: ${device.substring(0,8)}`);
                            result = { result: `Device ${device} is now ${act}.` };
                            break;
                        case 'universalTranslator':
                            const { targetLanguage } = fc.args as any;
                            logText = `TRANSLATION MATRIX ENGAGED: ${targetLanguage.toUpperCase()}`;
                            setMobileStatus(`TRANS: ${targetLanguage.substring(0,3)}`);
                            result = { result: `Translation protocol active. Translating to ${targetLanguage}.` };
                            break;
                        case 'webSearch':
                            const { query: searchQuery } = fc.args as any;
                            logText = `SEARCHING NET: ${searchQuery}`;
                            setMobileStatus('NET SEARCH');
                            // Actually open the search if requested, but generally just getting info is better.
                            // However, strictly adhering to 'advanced access', we provide the option.
                            // We won't auto-open to avoid disrupting the conversation flow unless necessary, 
                            // but the AI can say "I've opened the results" if it chooses to suggest it.
                            result = { result: `Search simulation: Latest information found for '${searchQuery}'.` };
                            break;
                        case 'mobileSystemControl':
                            const { feature, state } = fc.args as any;
                            logText = `SYS OVERRIDE: ${feature} -> ${state}`;
                            setMobileStatus(`${feature.toUpperCase()}: ${state.toUpperCase()}`);
                            result = { result: `System setting ${feature} set to ${state}.` };
                            break;
                        case 'appManager':
                            const { appName, action: appAction } = fc.args as any;
                            logText = `APP MGMT: ${appName} (${appAction})`;
                            setMobileStatus(`APP: ${appName.toUpperCase()}`);
                            // Mock App launching (some might work if they have registered schemes)
                            if (appAction === 'open') {
                                // Fallback to google search for the app if no scheme
                                // window.open(`https://play.google.com/store/search?q=${appName}`, '_blank');
                            }
                            result = { result: `Application ${appName} ${appAction}ed.` };
                            break;
                        case 'calendarManager':
                            const { action: calAction } = fc.args as any;
                            logText = `CALENDAR: ${calAction}`;
                            setMobileStatus(`CALENDAR`);
                            result = { result: `Calendar updated. Event ${calAction}ed.` };
                            break;
                        case 'cameraControl':
                            const { action: camAction } = fc.args as any;
                            logText = `CAMERA: ${camAction}`;
                            setMobileStatus(camAction.toUpperCase());
                            result = { result: `Camera ${camAction} executed.` };
                            break;
                    }

                    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'system', text: logText, timestamp: new Date() }]);

                    sessionPromise.then(session => session.sendToolResponse({
                        functionResponses: {
                            id: fc.id,
                            name: fc.name,
                            response: result
                        }
                    }));
                }
            }
          },
          onclose: () => {
            setConnectionState(ConnectionState.DISCONNECTED);
            setMobileStatus('DISCONNECTED');
            if (wakeLockRef.current) {
                wakeLockRef.current.release();
                wakeLockRef.current = null;
            }
          },
          onerror: (err) => {
            console.error(err);
            setConnectionState(ConnectionState.ERROR);
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'system', text: 'Connection Error.', timestamp: new Date() }]);
            setMobileStatus('ERROR');
          }
        }
      });
      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Connection failed", error);
      setConnectionState(ConnectionState.ERROR);
    }
  }, []);

  const disconnect = useCallback(async () => {
    if (sessionPromiseRef.current) {
        // Close session logic
    }
    
    if (inputSourceRef.current) inputSourceRef.current.disconnect();
    if (processorRef.current) processorRef.current.disconnect();
    if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach(t => t.stop());
    }
    if (frameIntervalRef.current) {
        clearInterval(frameIntervalRef.current);
        frameIntervalRef.current = null;
    }
    if (wakeLockRef.current) {
        wakeLockRef.current.release();
        wakeLockRef.current = null;
    }

    setConnectionState(ConnectionState.DISCONNECTED);
    setMobileStatus('OFFLINE');
  }, []);


  // Vision Logic
  useEffect(() => {
    if (!isVisionEnabled || connectionState !== ConnectionState.CONNECTED || !sessionPromiseRef.current) {
        if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
        return;
    }

    const startVideo = async () => {
        try {
            const videoStream = await navigator.mediaDevices.getUserMedia({ video: true });
            if (videoRef.current) {
                videoRef.current.srcObject = videoStream;
                await videoRef.current.play();
                
                frameIntervalRef.current = window.setInterval(() => {
                    if (canvasRef.current && videoRef.current && sessionPromiseRef.current) {
                        const ctx = canvasRef.current.getContext('2d');
                        if (ctx) {
                            canvasRef.current.width = videoRef.current.videoWidth * 0.5; // Scale down
                            canvasRef.current.height = videoRef.current.videoHeight * 0.5;
                            ctx.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
                            
                            canvasRef.current.toBlob(async (blob) => {
                                if (blob) {
                                    const base64 = await blobToBase64(blob);
                                    sessionPromiseRef.current?.then(session => {
                                        session.sendRealtimeInput({
                                            media: {
                                                mimeType: 'image/jpeg',
                                                data: base64
                                            }
                                        });
                                    });
                                }
                            }, 'image/jpeg', 0.6);
                        }
                    }
                }, 1000); 
            }
        } catch (e) {
            console.error("Video permission denied", e);
            setIsVisionEnabled(false);
        }
    };

    startVideo();

    return () => {
        if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
        if (videoRef.current && videoRef.current.srcObject) {
             const stream = videoRef.current.srcObject as MediaStream;
             stream.getTracks().forEach(t => t.stop());
        }
    };
  }, [isVisionEnabled, connectionState]);

  return {
    connect,
    disconnect,
    connectionState,
    messages,
    audioVolume,
    isVisionEnabled,
    setIsVisionEnabled,
    videoRef,
    canvasRef,
    currentTranscript,
    mobileStatus
  };
};